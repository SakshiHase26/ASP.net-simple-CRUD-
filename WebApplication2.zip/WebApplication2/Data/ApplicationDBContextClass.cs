﻿using Microsoft.EntityFrameworkCore;
using WebApplication2.Models.Entities;

namespace WebApplication2.Data
{
    public class ApplicationDBContextClass:DbContext
    {
        public ApplicationDBContextClass(DbContextOptions<ApplicationDBContextClass> options):base(options)    
        {
            
        }

       public DbSet<Student> Students { get; set; }
    }
}
